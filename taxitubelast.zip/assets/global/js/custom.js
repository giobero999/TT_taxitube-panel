//****************** YOUR CUSTOMIZED JAVASCRIPT **********************//


	$('#set-time-check').click(function(){
    
    	


})